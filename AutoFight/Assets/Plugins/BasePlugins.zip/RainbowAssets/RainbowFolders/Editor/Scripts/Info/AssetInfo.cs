﻿namespace Borodar.RainbowFolders.Editor
{
    public class AssetInfo
    {
        public const string STORE_ID = "50668";
        public const string NAME = "Rainbow Folders";
        public const string VERSION = "0.9";
        public const string HELP_URL = "http://www.borodar.com/stuff/rainbowfolders/docs/quickstart_v" + VERSION + ".pdf";
    }
}