﻿namespace Borodar.RainbowFolders.Editor
{
    public enum FolderPlatformName
    {
        Android = 0,
        iOS = 1,
        Mac = 2,
        WebGL = 3,
        Windows = 4
    }
}
