﻿namespace Borodar.RainbowFolders.Editor
{
    public enum FolderColorName
    {
        Red = 0,
        Vermilion = 1,
        Orange = 2,
        Amber = 3,
        Yellow = 4,
        Lime = 5,
        Chartreuse = 6,
        Harlequin = 7,
        Green = 8,
        Emerald = 9,
        SpringGreen = 10,
        Aquamarine = 11,
        Cyan = 12,
        SkyBlue = 13,
        Azure = 14,
        Cerulean = 15,
        Blue = 16,
        Indigo = 17,
        Violet = 18,
        Purple = 19,
        Magenta = 20,
        Fuchsia = 21,
        Rose = 22,
        Crimson = 23
    }
}