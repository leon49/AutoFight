﻿namespace Sirenix.OdinInspector.Demos
{
    using UnityEngine;

    public class Foo : MonoBehaviour
    {
        public int G, H, I;
    }
}