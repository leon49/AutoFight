#-*-coding:utf-8-*- 
# encoding=utf8 
import xlrd
import sys
reload(sys)

sys.setdefaultencoding('utf-8')

ch = sys.argv[1]
data_lan = xlrd.open_workbook(u"translate/zh-CN.xlsx")


def getLan(key):
	table = data_lan.sheets()[0]
	list = []
	for i in range(table.nrows):
		row = table.row(i)
		##if(key in row[2].value):
		##print row[2].value
		content = str(row[2].value)
		##print content
		if  content.find(key) != -1 :
			list.append( str(row[1].value) + "\t:\t" + content)
	return list		

print ch
for s in getLan(ch):
	print s