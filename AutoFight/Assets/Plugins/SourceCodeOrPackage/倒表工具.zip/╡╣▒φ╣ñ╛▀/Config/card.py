#-*-coding:utf-8-*- 
import xlrd
import sys

searchType = sys.argv[1]


data_lan = xlrd.open_workbook(u"translate/zh-CN.xlsx")
data_card = xlrd.open_workbook(u"data/新卡牌表.xlsx")
data_intention = xlrd.open_workbook("data/Intentions.xlsx")

def getRowByKey(data, key, index):
	table = data.sheets()[0]
	for i in range(table.nrows):
		row = table.row(i)
		if row[index].value == key:
			return row

	
def searchIntention(key):
	return getRowByKey(data_intention,key,0)

			
def getLan(key):
	row = getRowByKey(data_lan,key,1)
	return row[2].value
	

def FormatCard(row):
	return  u"卡牌 %(key)d  %(name)s "\
	%{'key':row[0].value,'name': getLan(row[1].value)}
		
def FormatIntention(row):
	return u"\t%(timming)s\t\t%(target)s\t\t%(condition)s\t\t%(function)s"\
	%{'key':row[0].value, 'timming':row[1].value, 'target':row[2].value, 'condition':row[3].value, 'function':row[6].value}

def PrintCardByID(key):
	row =  getRowByKey(data_card,key,0)
	print FormatCard(row)
	
	print("\t时机\t\t\t对象\t\t\t条件\t\t\t效果")
	intentions = row[13].value.split('|')
	for i in intentions:
		print  FormatIntention(searchIntention(i)) 
		
def PrintCardByName(key):
	row =  getRowByKey(data_card,key,1)
	print FormatCard(row)
	
	print("\t时机\t\t\t对象\t\t\t条件\t\t\t效果")
	intentions = row[13].value.split('|')
	for i in intentions:
		print  FormatIntention(searchIntention(i)) 
		
		
if searchType == "id":
	PrintCardByID(eval(sys.argv[2]))
	
if searchType == "name":
	PrintCardByName(sys.argv[2])


