cd ~/work/EdgeOfDream_Docs/Config/
if [ $1 == "lan" ]; then
    python lan.py $2
elif [ $1 == "buff" ]; then
    python buff.py $2 $3 
elif [ $1 == "card" ]; then
		python card.py $2 $3
else
    echo "you had enter unexpected word"
fi

cd -