#-*-coding:utf-8-*- 
import xlrd
import sys

searchType = sys.argv[1]


data_lan = xlrd.open_workbook(u"translate/zh-CN.xlsx")
data_buff = xlrd.open_workbook(u"data/新buff表.xlsx")
data_intention = xlrd.open_workbook("data/Intentions.xlsx")

def getRowByKey(data, key, index):
	table = data.sheets()[0]
	for i in range(table.nrows):
		row = table.row(i)
		if row[index].value == key:
			return row

	
def searchIntention(key):
	return getRowByKey(data_intention,key,0)

			
def getLan(key):
	row = getRowByKey(data_lan,key,1)
	return row[2].value
	
#def formatPrint(str):
#	print('[{str:<{len}}\tx'.format(str=str+']',len=22-len(str.encode('GBK'))+len(str)))
			

def FormatBuff(row):
	return  "Buff %(key)d  %(name)s "\
	%{'key':row[0].value,'name': getLan(row[1].value + "_BuffName")}
		
def FormatIntention(row):
	return u"\t%(timming)s\t\t%(target)s\t\t%(condition)s\t\t%(function)s"\
	%{'key':row[0].value, 'timming':row[1].value, 'target':row[2].value, 'condition':row[3].value, 'function':row[6].value}

def PrintBuffByID(key):
	row =  getRowByKey(data_buff,key,0)
	print FormatBuff(row)
	
	print("\t时机\t\t\t对象\t\t\t条件\t\t\t效果")
	intentions = row[9].value.split('|')
	for i in intentions:
		print  FormatIntention(searchIntention(i)) 
		
def PrintBuffByName(key):
	row =  getRowByKey(data_buff,key,2)
	print FormatBuff(row)
	
	print("\t时机\t\t\t对象\t\t\t条件\t\t\t效果")
	intentions = row[9].value.split('|')
	for i in intentions:
		print  FormatIntention(searchIntention(i)) 
		
		
if searchType == "id":
	PrintBuffByID(eval(sys.argv[2]))
if searchType == "name":
	PrintBuffByName(sys.argv[2])


