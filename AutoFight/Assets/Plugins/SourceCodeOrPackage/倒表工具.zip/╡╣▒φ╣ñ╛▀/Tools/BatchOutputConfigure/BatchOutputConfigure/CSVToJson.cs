﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;

namespace CSVToJsonAndCS
{
    public enum ParamDataType
    {
        ParamDataType_None = 0,
        ParamDataType_OnlyKey,
        ParamDataType_OnlyParam,
        ParamDataType_KeyAndParam,
        ParamDataType_Property,
        ParamDataType_Value,
        ParamDataType_ResAndParam,
        ParamDataType_SoundAndParam
    }

    public enum ParamType
    {
        ParamType_Int = 0,
        ParamType_String,
        ParamType_Float,
        ParamType_UInt,
        ParamType_long,
        ParamType_MultipleObjects,
        ParamType_IntentionCondition
    }


    [Serializable]
    public class ParamData
    {
        public ParamDataType type;
        public string paramName;
        public ParamType paramType;
    }

    class CSVToJson
    {
        public static ParamType getTypeFromString(string type){
            if (type.Equals("string"))
            {
                return ParamType.ParamType_String;
            }
            if (type.Equals("float"))
            {
                return ParamType.ParamType_Float;
            }
            if (type.Equals("uint"))
            {
                return ParamType.ParamType_UInt;
            }
            if (type.Equals("long"))
            {
                return ParamType.ParamType_long;
            }
            if(type.Equals("stringArray") )
            {
                return ParamType.ParamType_MultipleObjects;
            }
            if(type.Equals("intentionCondition"))
            {
                return ParamType.ParamType_IntentionCondition;
            }
            return ParamType.ParamType_Int;
        }
        
        public static string commonCSVToJson(string csvFilePath, string csOnlyFilePath, string jsonOnlyFilePath, string fileName, string baseDirPath, string configVersionDirPath, out bool isNewVersion, out List<ParamData> listParamData, string excelName, TabelType fileType = TabelType.NORMAL)
        {
            string result = "";
            int index = csvFilePath.LastIndexOf("\\");
            string jsonFilePath = jsonOnlyFilePath + "\\" + fileName + ".txt";
            string csFilePath = csOnlyFilePath + "\\" + fileName + ".cs";
            string jsonConfigPath = configVersionDirPath + "\\" + fileName + ".txt";

            StreamReader srReadFile = new StreamReader(csvFilePath);
            // 读取流直至文件末尾结束

            string[] arrNotes = null;
            int count = 0;

            List<string> arrContent = new List<string>();
            List<ParamData> arrParam = new List<ParamData>();
            listParamData = arrParam;

            List<string> arrEnumString = new List<string>();
            List<string> arrEnumNoteString = new List<string>();
            int colEnum = -1;
            int colEnumNote = -1;
            string strEnumName = null;
            bool special = false;
            int keyCount = 0;

            List<string> listNote = new List<string>();
            bool defaultConfig = (fileType == TabelType.DEFAULT) ? true : false;

            string src_path = "";
            string dest_path = "";

            isNewVersion = false;
            Dictionary<string, Dictionary<string, string>> dicJsonConfigure = new Dictionary<string, Dictionary<string, string>>();

            while (!srReadFile.EndOfStream)
            {
                string strReadLine = srReadFile.ReadLine(); //读取每行数据
                string[] arrString = strReadLine.Split(',');
                if (arrString.Length <= 0)
                {
                    continue;
                }

                bool isSuccess = false;
                for (int i = 0; i < arrString.Length; ++i )
                {
                    if (arrString[i].Length > 0)
                    {
                        isSuccess = true;
                        break;
                    }
                }

                if (isSuccess == false)
                {
                    continue;
                }


                if (defaultConfig)
                {
                    if (count == 0)
                    {
                        count++;
                        continue;
                    }

                    if (arrString.Length < 3)
                    {
                        count++;
                        continue;
                    }

                    string note = arrString[0];
                    listNote.Add(note);

                    string property = arrString[1];
                    property = property.Trim();
                    ParamData data = new ParamData();
                    data.type = ParamDataType.ParamDataType_None;
                    arrParam.Add(data);

                    string[] arrTemp = property.Split(':');
                    if (arrTemp.Length == 2)
                    {
                        data.paramName = arrTemp[0];
                        data.paramName = data.paramName.Trim();
                        data.type = ParamDataType.ParamDataType_OnlyParam;
                       
                        string type = arrTemp[1];
                        type = type.Trim();
                        data.paramType = getTypeFromString(type);
                    }

                    string value = arrString[2];
                    arrContent.Add(value);
                    count++;
                    continue;
                }

                if (count == 0)
                {
                    arrNotes = arrString;

                    for (int i = 0; i < arrString.Length; ++i)
                    {
                        string str = arrString[i];
                        str = str.Trim();
                        if (str.Equals("enum"))
                        {
                            colEnum = i;
                            break;
                        }
                    }
                }
                else if (count == 1)
                {
                    for (int i = 0; i < arrString.Length; ++i)
                    {
                        ParamData data = new ParamData();
                        data.type = ParamDataType.ParamDataType_None;
                        arrParam.Add(data);
                        string str = arrString[i];
                        str = str.Trim();
                        if (str.Length == 0)
                        {
                            continue;
                        }

                        if (i == colEnum)
                        {
                            strEnumName = str;
                            continue;
                        }

                        if (str.Contains(";"))
                        {
                            string[] arrTemp = str.Split(';');
                            if (arrTemp.Length == 2)
                            {
                                string left = arrTemp[0];
                                if (left.Equals("key"))
                                {
                                    keyCount++;
                                    data.type = ParamDataType.ParamDataType_OnlyKey;
                                    string temp = arrTemp[1];
                                    temp = temp.Trim();
                                    arrTemp = temp.Split(':');
                                    if (arrTemp.Length == 2)
                                    {
                                        data.type = ParamDataType.ParamDataType_KeyAndParam;
                                        data.paramName = arrTemp[0];
                                        data.paramName = data.paramName.Trim();
                                        string type = arrTemp[1];
                                        type = type.Trim();
                                        data.paramType = getTypeFromString(type);
                                    }
                                }
                                else if (left.Equals("res"))
                                {
                                    data.type = ParamDataType.ParamDataType_ResAndParam;
                                    data.paramType = ParamType.ParamType_String;

                                    string temp = arrTemp[1];
                                    temp = temp.Trim();
                                    arrTemp = temp.Split(':');
                                    data.paramName = arrTemp[0];
                                    data.paramName = data.paramName.Trim();
                                }
                                else if (left.Equals("sound"))
                                {
                                    data.type = ParamDataType.ParamDataType_SoundAndParam;
                                    data.paramType = ParamType.ParamType_String;

                                    string temp = arrTemp[1];
                                    temp = temp.Trim();
                                    arrTemp = temp.Split(':');
                                    data.paramName = arrTemp[0];
                                    data.paramName = data.paramName.Trim();
                                }
                            }

                        }
                        else if (str.Equals("key"))
                        {
                            keyCount++;
                            data.type = ParamDataType.ParamDataType_OnlyKey;
                        }
                        else if (str.Equals("property"))
                        {
                            special = true;
                            data.type = ParamDataType.ParamDataType_Property;
                        }
                        else if (str.Equals("value"))
                        {
                            data.type = ParamDataType.ParamDataType_Value;
                        }
                        else if (str.Contains(':'))
                        {
                            string[] arrTemp = str.Split(':');
                            if (arrTemp.Length == 2)
                            {
                                data.paramName = arrTemp[0];
                                data.paramName.Trim();
                                if (data.paramName.Equals("enum_note"))
                                {
                                    colEnumNote = i;
                                    continue;
                                }

                                data.type = ParamDataType.ParamDataType_OnlyParam;
                                string type = arrTemp[1];
                                type = type.Trim();
                                data.paramType = getTypeFromString(type);
                            }
                        }
                    }
                }
                else
                {

                    arrContent.Add(strReadLine);

                    if (colEnum >= 0 && arrString[colEnum].Length > 0)
                    {
                        
                        arrEnumString.Add(arrString[colEnum]);
                    }

                    if (colEnumNote >= 0 && arrString[colEnumNote].Length > 0)
                    {
  
                        arrEnumNoteString.Add(arrString[colEnumNote]);
                    }
                }
                count++;
            }

            if (listNote.Count > 0)
            {
                arrNotes = listNote.ToArray();
            }

            // 关闭读取流文件
            srReadFile.Close();

            //string csContentText = "";

            if (arrEnumString.Count() > 0)
            {
                string csText = "using System;\r\n\r\n";
                string temp = "namespace ProtoConfig { \r\n\r\n";
                temp += "public enum " + strEnumName + " {\r\n";

                Dictionary<string, string> dicNew = new Dictionary<string, string>();
                for (int i = 0; i < arrEnumString.Count(); ++i)
                {
                    if (arrEnumString[i].Length == 0)
                    {
                        continue;
                    }

                    if (i < arrEnumNoteString.Count)
                    {
                        string str = "\t" + arrEnumString[i] + ", //" + arrEnumNoteString[i] + "\r\n";
                        temp += str;
                    }
                    else
                    {
                        string str = "\t" + arrEnumString[i] + ",\r\n";
                        temp += str;
                    }
                    
                }

                temp += "}\r\n\r\n";
                temp += "}\r\n\r\n";
                csText = csText + temp;
                File.WriteAllText(csFilePath, csText);
                //csText = csText + temp + "public class " + fileName + " {\r\n";
            }
            else
            {
               // csText = csText + "public class " + fileName + " {\r\n";
            }



            if (special)
            {
                Dictionary<string, string> dicAll = new Dictionary<string, string>();

                Dictionary<string, string> dicNew = new Dictionary<string, string>();
                for (int i = 0; i < arrContent.Count; ++i)
                {
                    string content = arrContent[i];
                    string[] arrString = content.Split(',');
                    if (arrString.Length < 3)
                    {
                        continue;
                    }
                    dicAll.Add(arrString[1], arrString[2]);
                }

                if (csOnlyFilePath.Length > 0)
                {
                    //csText += csContentText + "}";
                    //File.WriteAllText(csFilePath, csText);
                }

                string text = JsonConvert.SerializeObject(dicAll, Formatting.Indented);
                File.WriteAllText(jsonFilePath, text);
            }
            else
            {
                if (csOnlyFilePath.Length > 0)
                {
                    Dictionary<string, string> dicNew = new Dictionary<string, string>();
                    for (int i = 0; i < arrParam.Count; ++i)
                    {
                        ParamData data = arrParam[i];
                        if (data.type == ParamDataType.ParamDataType_OnlyParam ||
                            data.type == ParamDataType.ParamDataType_KeyAndParam || 
                            data.type == ParamDataType.ParamDataType_ResAndParam ||
                            data.type == ParamDataType.ParamDataType_SoundAndParam)
                        {
                            
                        }
                    }

                    //csText += csContentText + "}";

                    //File.WriteAllText(csFilePath, csText);
                }

                Dictionary<string, Object> dicAll = new Dictionary<string, Object>();

                if (defaultConfig)
                {
                    for (int i = 0; i < arrContent.Count; ++i)
                    {
                        string str = arrContent[i];
                        str = str.Trim();
                        if (str.Length == 0)
                        {
                            continue;
                        }

                        ParamData data = arrParam[i];
                        if (data.type == ParamDataType.ParamDataType_None)
                        {
                            continue;
                        }

                        if (data.paramType == ParamType.ParamType_Int)
                        {
                            if (str.Contains("."))
                            {
                                int value = (int)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                dicAll.Add(data.paramName, value);
                            }
                            else
                            {
                                dicAll.Add(data.paramName, Int32.Parse(str));
                            }
                        }
                        else if (data.paramType == ParamType.ParamType_UInt)
                        {
                            if (str.Contains("."))
                            {
                                uint value = (uint)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                dicAll.Add(data.paramName, value);
                            }
                            else
                            {
                                dicAll.Add(data.paramName, UInt32.Parse(str));
                            }
                        }
                        else if (data.paramType == ParamType.ParamType_long)
                        {
                            if (str.Contains("."))
                            {
                                long value = (long)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                dicAll.Add(data.paramName, value);
                            }
                            else
                            {
                                dicAll.Add(data.paramName, Int64.Parse(str));
                            }
                        }
                        else if (data.paramType == ParamType.ParamType_Float)
                        {
                            dicAll.Add(data.paramName, Double.Parse(str));
                        }
                        else
                        {
                            dicAll.Add(data.paramName, str);
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < arrContent.Count; ++i)
                    {
                        string content = arrContent[i];
                        string[] arrString = content.Split(',');

                        int keyIndex = 0;

                        Dictionary<string, Object> currentDic = dicAll;

                        Dictionary<string, Object> dicObject = new Dictionary<string, Object>();

                        string res_key = fileName;
                        for (int j = 0; j < arrString.Length; ++j)
                        {
                            string str = arrString[j];
                            str =  str.Trim();
                            ParamData data = null;
                            try
                            {
                                data = arrParam[j];
                            }
                            catch
                            {

                            }                            
                            
                            if (str.Length <= 0 && data != null && data.paramType != ParamType.ParamType_String)
                            {
                                continue;
                            }

                            if (j >= arrParam.Count)
                            {
                                continue;
                            }

                            try
                            {
                                if (data.type == ParamDataType.ParamDataType_None)
                                {
                                    continue;
                                }
                                else if (data.type == ParamDataType.ParamDataType_OnlyKey || data.type == ParamDataType.ParamDataType_KeyAndParam)
                                {
                                    keyIndex++;
                                    res_key += "_" + str;
                                    if (currentDic.ContainsKey(str) == false)
                                    {
                                        if (keyIndex == keyCount)
                                        {
                                            currentDic.Add(str, dicObject);
                                        }
                                        else
                                        {
                                            Dictionary<string, Object> newDic = new Dictionary<string, Object>();
                                            currentDic.Add(str, newDic);
                                            currentDic = newDic;
                                        }
                                    }
                                    else
                                    {
                                        currentDic = (Dictionary<string, Object>)currentDic[str];
                                    }

                                    if (data.type == ParamDataType.ParamDataType_KeyAndParam)
                                    {
                                        if (data.paramType == ParamType.ParamType_Int)
                                        {
                                            if (str.Contains("."))
                                            {
                                                int value = (int)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                                dicObject.Add(data.paramName, value);
                                            }
                                            else
                                            {
                                                dicObject.Add(data.paramName, Int32.Parse(str));
                                            }
                                        }
                                        else if (data.paramType == ParamType.ParamType_Float)
                                        {
                                            dicObject.Add(data.paramName, Double.Parse(str));
                                        }
                                        else if (data.paramType == ParamType.ParamType_UInt)
                                        {
                                            if (str.Contains("."))
                                            {
                                                uint value = (uint)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                                dicObject.Add(data.paramName, value);
                                            }
                                            else
                                            {
                                                dicObject.Add(data.paramName, UInt32.Parse(str));
                                            }
                                        }
                                        else if (data.paramType == ParamType.ParamType_long)
                                        {
                                            if (str.Contains("."))
                                            {
                                                long value = (long)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                                dicObject.Add(data.paramName, value);
                                            }
                                            else
                                            {
                                                dicObject.Add(data.paramName, Int64.Parse(str));
                                            }
                                        }
                                        else
                                        {
                                            dicObject.Add(data.paramName, str);
                                        }
                                    }
                                }

                                else if (data.type == ParamDataType.ParamDataType_SoundAndParam)
                                {
                                    bool ret = CSVToJson.moveMusic(str, src_path, dest_path);
                                    if (ret == false)
                                    {
                                        result = result + "Error: [" + str + "] 文件不存在！！！\r\n";
                                    }
                                    dicObject.Add(data.paramName, str);      
                                }
                                else if (data.type == ParamDataType.ParamDataType_OnlyParam)
                                {
                                    if (data.paramType == ParamType.ParamType_Int)
                                    {
                                        if (str.Contains("."))
                                        {
                                            int value = (int)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                            dicObject.Add(data.paramName, value);
                                        }
                                        else
                                        {
                                            dicObject.Add(data.paramName, Int32.Parse(str));
                                        }
                                    }
                                    else if (data.paramType == ParamType.ParamType_UInt)
                                    {
                                        if (str.Contains("."))
                                        {
                                            uint value = (uint)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                            dicObject.Add(data.paramName, value);
                                        }
                                        else
                                        {
                                            dicObject.Add(data.paramName, UInt32.Parse(str));
                                        }
                                    }
                                    else if (data.paramType == ParamType.ParamType_long)
                                    {
                                        if (str.Contains("."))
                                        {
                                            long value = (long)Math.Round(Double.Parse(str), 0, MidpointRounding.AwayFromZero);
                                            dicObject.Add(data.paramName, value);
                                        }
                                        else
                                        {
                                            dicObject.Add(data.paramName, Int64.Parse(str));
                                        }
                                    }
                                    else if (data.paramType == ParamType.ParamType_Float)
                                    {
                                        dicObject.Add(data.paramName, Double.Parse(str));
                                    }
                                    else
                                    {
                                        dicObject.Add(data.paramName, str);
                                    }

                                }
                            }
                            catch (Exception e)
                            {
                                continue;
                            }
                        }
                    }
                }


                string text = JsonConvert.SerializeObject(dicAll, Formatting.Indented);
                File.WriteAllText(jsonFilePath, text);
            }

            return result;
        }

        private static bool moveMusic(string name, string src_path, string dest_path)
        {
            if (src_path.Length == 0 || dest_path.Length == 0)
            {
                return true;
            }

            //if (name.Contains(".mp3") || name.Contains(".wav"))
            {
                string ext = ".wav";
                string srcFullPath = src_path + "\\" + name + ext;
                if (File.Exists(srcFullPath) == false)
                {
                    ext = ".mp3";
                    srcFullPath = src_path + "\\" + name + ext;
                    if (File.Exists(srcFullPath) == false)
                    {
                        return false;
                    }
                    
                }

                string destFullPath = dest_path + "\\" + name + ext;
                File.Copy(srcFullPath, destFullPath, true);
                return true;
            }

            return true;  
        }
    }
}
