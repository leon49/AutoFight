﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using BatchOutputConfigure;

public class LogTime
{
    private static long startTime = 0;
    private static int ms = 10000;
    public static RichTextBox TextBox;
    public static set_Text SetText;
    public static void init()
    {
        startTime = System.DateTime.Now.ToFileTimeUtc();
        preTime = startTime;
        LogStepTime("Init");
    }
    
    private static long preTime = 0;
    
    public static void LogStepTime(string aStepName = "")
    {
        long timeNow = System.DateTime.Now.ToFileTimeUtc();
        long timeGap = timeNow - preTime;
        long timeGapFromStart = timeNow - startTime;
        preTime = timeNow;

        Form1.allResult += aStepName+timeGapFromStart / ms + "   -" + timeGap / ms+"\r\n";
        TextBox.Invoke(SetText, new object[] { Form1.allResult, false, "" });
    }
}