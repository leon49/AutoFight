﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.Xml;
using System.IO;
using CSVToJsonAndCS;
using System.Threading;
using Newtonsoft.Json;
//using SharpSvn;
using System.Diagnostics;
using System.Collections;
using Newtonsoft.Json.Linq;
using System.CodeDom.Compiler;
using System.Reflection;
using System.Text.RegularExpressions;

namespace BatchOutputConfigure
{
    public class ConfigPath
    {
        public static string ProjectName = "";
    }

    class JsonToProtoBuf : MarshalByRefObject
    {
        public static string dirPath = ""; //工程根目录
        public static string lib_proto{ get{ return Path.Combine(dirPath, "Tools\\protobuf-net\\Full\\unity\\protobuf-net.dll"); }}
        public static string exe_proto_gen { get { return Path.Combine(dirPath,"Tools\\protobuf-net\\ProtoGen\\protogen.exe"); } }
        public static string exe_proto_precompile { get { return Path.Combine(dirPath,"Tools\\protobuf-net\\Precompile\\precompile.exe"); } }


        private static string _UnityProjPath;
        //unity项目目录
        public static string UnityProjPath
        {
            get { return _UnityProjPath; }
            set { _UnityProjPath = value; }
        }

        //config dll 输出目录
        public static string dll_config { get { return Path.Combine(UnityProjPath,"Assets\\References\\config-proto.dll"); } }

        //serializer dll 输出目录
        public static string dll_serializer { get { return Path.Combine(UnityProjPath,"Assets\\References\\config-proto-serializer.dll"); } }
        
        public static string proto_temp_Path { get { return Path.Combine(UnityProjPath,"ConfigureProtoBuf\\"); } }
        
        //编译产生cs的临时目录
//        public static string cs_Path { get { return Path.Combine(UnityProjPath,"Assets\\References\\Config_CSFiles\\"); } }
        //保存生成的proto文件的目录
        public static string proto_file_path { get { return Path.Combine(UnityProjPath, "Assets\\Resources\\ProtoBufConfigure"); } }

        //proto配置空间名
        const string protoPackageName = "ProtoConfig";

        public static string ConvertJsonToProtoBuf(string serverProtoDataFilePath, List<string> jsonFileList, List<List<ParamData>> configParamList,Control ui,set_Text del, string log)
        {
            string exePath = Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath);

            List<string> protoFileList = new List<string>();
            List<string> nameList = new List<string>();

            #region check eviroment
            if (!File.Exists(lib_proto))
            {
                log += "\r\n错误：protobuf-net.dll不存在 \r\n" + lib_proto;
                ui.Invoke(del, new object[] { log, false, "" });
                return log;
            }
            if (!File.Exists(exe_proto_gen))
            {
                log += "\r\n错误：protogen不存在 \r\n"  + exe_proto_gen;
                ui.Invoke(del, new object[] { log, false, "" });
                return log;
            }
            #endregion

            //清理旧的文件
            File.Delete(dll_config);
            File.Delete(dll_serializer);

            #region  json 转 proto
            log += "\r\n开始转换protobuf";
            ui.Invoke(del, new object[] { log, false, "" });

            System.Func<string, List<ParamData>, bool> buildProto = (jsonFile, paramList) =>
            {
                string fileName = Path.GetFileNameWithoutExtension(jsonFile);
                string file_proto =  proto_temp_Path + "\\" + fileName + ".proto";
                string file_version =  proto_temp_Path + "\\" + fileName + "_version.txt";

                if (paramList.Count == 0)
                {
                    log += "\r\n" + fileName + " 生成配置出错，不生成proto";
                    return false;
                }

                bool hasConditionType = false;
                for (int t = 0; t < paramList.Count; t++)
                {
                    if (paramList[t].paramType == ParamType.ParamType_IntentionCondition)
                    {
                        hasConditionType = true;
                    }
                }

                if (File.Exists(file_proto))
                    File.Delete(file_proto);

                protoFileList.Add(file_proto);
                nameList.Add(fileName);

                //读取版本文件
                JObject protoVersion = File.Exists(file_version) ? JObject.Parse(File.ReadAllText(file_version)) : new JObject();

                string content = "package " + protoPackageName + ";\n\n";
                content += "message " + fileName + "List\n{\nrepeated " + fileName + " list=1;\n}\n";

                if (hasConditionType)
                {
                    content += "message IntentionCondition" 
                               + "\n{\nrepeated string conditionParams=1;\n}\n";
                }
                
                content += "message " + fileName + " {\n\n";
                int keyCount = 0;
                foreach (ParamData param in paramList)
                {
                    if (param.type == ParamDataType.ParamDataType_KeyAndParam || param.type == ParamDataType.ParamDataType_OnlyKey)
                    {
                        keyCount++;
                        content +=  GetProroTypeString(param.paramType) + " proro_key_" + keyCount + " =" + keyCount + ";\n\n";
                    }

                    if (param.type == ParamDataType.ParamDataType_OnlyKey || param.type == ParamDataType.ParamDataType_None)
                        continue;
 
                    int index = GetProtoIndex(protoVersion, param.paramName);
                    content +=  GetProroTypeString(param.paramType) + " " + param.paramName + " =" + index + ";\n\n";
                }
                content += "}\n\n";

                const string version_key_count = "proto_config_key_count";
                if (protoVersion[version_key_count] != null)
                {
                    if (protoVersion[version_key_count].Value<int>() != keyCount)
                    {
                        log += "\r\n错误：" + fileName + " 生成proto出错，key数量发生变化，前后不兼容！！！！";
                        log += "\r\n记录文件：" + file_version;
                        return false;
                    }
                }
                else
                    protoVersion[version_key_count] = keyCount;
                
                //生成proto文件
                File.WriteAllText(file_proto, content);
                //生成版本文件
                File.WriteAllText(file_version, protoVersion.ToString());
                return true;
            };

            for (int i = 0; i < jsonFileList.Count;i++ )
            {
                bool result = buildProto(jsonFileList[i], configParamList[i]);
                ui.Invoke(del, new object[] { log, false, "" });
                if (!result)
                    return log;
            }

            #endregion
            
            LogTime.LogStepTime("json 转 proto over");
            
            #region proto 转 cs
            log += "\r\n开始生成cs文件";
            ui.Invoke(del, new object[] { log, false, "" });
            //调用protogen生成cs
            System.Func<string,string, bool> proto2cs = (protofile, csFile)=>
            {

                var info = new ProcessStartInfo(exe_proto_gen);
                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                info.RedirectStandardError = true;
                info.Arguments = string.Format("-i:{0} -o:{1}{2}.cs", protofile, proto_temp_Path, csFile);
                info.WorkingDirectory = proto_temp_Path;

                var process = new Process();
                process.StartInfo = info;
                process.Start();

                StreamReader myStreamReader = process.StandardError;
                string rInfo = myStreamReader.ReadToEnd();
                process.WaitForExit();

                #region log
                Debug.WriteLine(csFile + "\n" + rInfo);
                if ("".Equals(rInfo))
                    log += "\r\n" + csFile + " proto编译成功";
                else
                {
                    log += "\r\n" + csFile + " proto编译失败";
                    log += "\r\n" + rInfo;
                    return false;
                }
                #endregion
                return true;
            };

            for (int i = 0; i < protoFileList.Count; i++)
            {
                bool result = proto2cs(protoFileList[i], nameList[i]);
                ui.Invoke(del, new object[] { log, false, "" });
                if (!result)
                    return log;
            }
            #endregion

            LogTime.LogStepTime("proto 转 cs over");
            
            #region 编译dll文件
            System.Func<bool> buildCSFiles = ()=>
            {
                var files = Directory.GetFiles(proto_temp_Path, "*.cs", SearchOption.TopDirectoryOnly);
                var codeProvider = CodeDomProvider.CreateProvider("CSharp", new Dictionary<string, string>() { { "CompilerVersion", "v2.0" } });
                var paras = new CompilerParameters();
                paras.CompilerOptions = "";
                paras.GenerateExecutable = false;
                paras.OutputAssembly = dll_config; //输出路径
                paras.ReferencedAssemblies.Add(lib_proto);//引用路径

                var result = codeProvider.CompileAssemblyFromFile(paras, files);

                if (result.Errors.Count > 0)
                {
                    log += "\r\nCS编译出错！！！！！";

                    string error = "";
                    foreach (CompilerError CompErr in result.Errors)
                        error += "Line number " + CompErr.Line + ", Error Number: " + CompErr.ErrorNumber + ", '" + CompErr.ErrorText + ";";

                    log += "\r\n " + error;
                    ui.Invoke(del, new object[] { log, false, "" });
                    return false;
                }
                else
                {
                    log += "\r\nCS编译成功";
                    ui.Invoke(del, new object[] { log, false, "" });
                }
                return true;
            };
            if (!buildCSFiles())
             return log;

            //调用precompile生成serializer的dll
            System.Func<bool> buildSerilizerDll = () =>
            {
                var process = new Process();
                var startInfo = new ProcessStartInfo(exe_proto_precompile);
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;
                startInfo.RedirectStandardError = true;
                startInfo.Arguments = dll_config + " -o:" + dll_serializer + " -access:public -t:ConfigSerializer";
                process.StartInfo = startInfo;
                process.Start();

                StreamReader precompileStreamReaderUnity = process.StandardError;
                string precompileInfoUnity = precompileStreamReaderUnity.ReadToEnd();
                process.Close();
                if ("".Equals(precompileInfoUnity))
                {
                    log += "\r\nprecompile DLL编译成功";
                    ui.Invoke(del, new object[] { log, false, "" });
                }
                else
                {
                    log += "\r\nprecompile DLL编译出错！！！！！";
                    log += "\r\n " + precompileInfoUnity;
                    ui.Invoke(del, new object[] { log, false, "" });
                    return false;
                }

                return true;
            };

            if (!buildSerilizerDll())
                return log;

            #endregion

            #region 序列化数据
            log += "\r\n开始序列化protobuf";
            ui.Invoke(del, new object[] { log, false, "" });
            //使用一个新的domain来运行加载dll的操作。这样dll可以ShadowCopyFiles，运行时可以删除修改
            AppDomainSetup setup = new AppDomainSetup();
            setup.ShadowCopyFiles = "true";
            var domain = AppDomain.CreateDomain("serializer", null, setup);
            // instantiate a helper object derived from MarshalByRefObject in other domain
            var handle = domain.CreateInstanceFrom(Assembly.GetExecutingAssembly().Location, typeof(JsonToProtoBuf).FullName);
            // unwrap it - this creates a proxy to Helper instance in another domain
            JsonToProtoBuf h = (JsonToProtoBuf)handle.Unwrap();
            h.SerializerData(protoPackageName, proto_file_path, serverProtoDataFilePath, dll_serializer, dll_config, jsonFileList,configParamList);
            AppDomain.Unload(domain);
            log += "\r\n结束序列化protobuf";
            ui.Invoke(del, new object[] { log, false, "" });
            #endregion
            
            LogTime.LogStepTime("序列化数据 over");

            return log;
        }
        private static int GetProtoIndex(JObject versionConfig,string protoName)
        {
            const string version_max_index = "proto_config_max_index";
            if (versionConfig[protoName]!=null)
            {
                return versionConfig[protoName].Value<int>();
            }
            int max =100;//属性值的index从101开始
            if (versionConfig[version_max_index] != null)
            {
                max = versionConfig[version_max_index].Value<int>();
            }
            ++max;
            versionConfig[protoName] = max;
            versionConfig[version_max_index] = max;
            return max;
        }


        //把数据序列化
        private void SerializerData(string protoPackageName, string protoDataFilePath, string serverProtoDataFilePath,
            string dllSerializerUnityPath, string dllProtoUnityPath, List<string> jsonFileList,
            List<List<ParamData>> configParamList)
        {
            //加载serializer的dll，获得serializer实例
            Assembly serializerAss = Assembly.LoadFrom(dllSerializerUnityPath);// Assembly.Load(File.ReadAllBytes(dllSerializerUnityPath));这个方法不能正确加载相关引用
            Type serializerType = serializerAss.GetType("ConfigSerializer");
            Object seriadlizerObj = Activator.CreateInstance(serializerType);
            MethodInfo serializerMethod = serializerType.GetMethod("Serialize", new Type[] { typeof(Stream), typeof(object) });

            //加载config-proto的dll
            Assembly protoAss = Assembly.LoadFrom(dllProtoUnityPath);// Assembly.Load(File.ReadAllBytes(dllProtoUnityPath));
            //解析json，反射构造proto对象，并序列化
            for (int i = 0; i < jsonFileList.Count; i++)
            {
                string jsonFilePath = jsonFileList[i];
                int startIndex = jsonFilePath.LastIndexOf("\\") + 1;
                int length = jsonFilePath.LastIndexOf(".") - startIndex;
                string fileName = jsonFilePath.Substring(startIndex, length);
                Type protoConfigType = protoAss.GetType(protoPackageName + "." + fileName);
                Type protoConfigListType = protoAss.GetType(protoPackageName + "." + fileName + "List");
                Object protoConfigListObj = Activator.CreateInstance(protoConfigListType);

                StreamReader read = new StreamReader(jsonFilePath);
                string strValue = read.ReadToEnd();
                read.Close();
                JObject jsonObj = JObject.Parse(strValue);

                List<object> result = new List<object>();
                ParseJObject2Proto(protoConfigType, result, jsonObj, 0,configParamList[i],protoAss,protoPackageName);

                PropertyInfo listProperty = protoConfigListType.GetProperty("list");
                IList list = listProperty.GetValue(protoConfigListObj) as IList;
                foreach (object o in result)
                    list.Add(o);
                
                //保存到bytes文件
                string protoConfigFilePath = protoDataFilePath + "\\" + fileName + ".bytes";
                File.Delete(protoConfigFilePath);
                FileStream fs = File.Open(protoConfigFilePath, FileMode.OpenOrCreate, FileAccess.Write);
               // fs.SetLength(0);
                serializerMethod.Invoke(seriadlizerObj, new object[] { fs, protoConfigListObj });
                fs.SetLength(fs.Position);
                fs.Close();

            }
        }
        private const string pattern = @"^\w+|(>=|==|<=|!=|<|>|##|!#|;)|([-+]?[0-9]*\.?[0-9]+|\S+)$";
        
        //递归把json转换成proto
        private static void ParseJObject2Proto(Type protoConfigType, List<object> result, JObject jobj, int deep,
            List<ParamData> configParam, Assembly assembly, string protoPackageName)
        {
            object protoObj = null;

            foreach (JProperty p in jobj.Children())
            {
                if (p.Value.Type == JTokenType.Object)
                {
                    //当前层还是key层，继续深入
                    ParseJObject2Proto(protoConfigType, result, p.Value as JObject, deep + 1,configParam,assembly,protoPackageName);
                }
                else
                {
                    //Debug.WriteLine("deep=" + deep + " path=" + p.Path + " name=" + p.Name + " value=" + p.Value.ToString());
                    if (protoObj == null)
                    {
                        protoObj = Activator.CreateInstance(protoConfigType);
                        string[] keys = p.Path.Split('.');
                        for (int i = 0; i < keys.Length - 1; i++)
                        {//路径包含当前的key，所有去掉最后一个就是所有key
                            string keyName = "proro_key_" + (i + 1);
                            
                            PropertyInfo keyPi = protoConfigType.GetProperty(keyName);
                            if(keyPi.PropertyType == typeof(uint))
                            {
                                uint keyValue = uint.Parse(keys[i]);
                                keyPi.SetValue(protoObj, keyValue, null);
                            }else if(keyPi.PropertyType == typeof(string)){
                                keyPi.SetValue(protoObj, keys[i], null);
                            }
                            else if (keyPi.PropertyType == typeof(float))
                            {
                                float keyValue = float.Parse(keys[i]);
                                keyPi.SetValue(protoObj, keyValue, null);
                            }
                            else if (keyPi.PropertyType == typeof(long))
                            {
                                long keyValue = long.Parse(keys[i]);
                                keyPi.SetValue(protoObj, keyValue, null);
                            }
                            else
                            {
                                int keyValue = int.Parse(keys[i]);
                                keyPi.SetValue(protoObj, keyValue, null);
                            }
                        }
                    }
                    switch (p.Value.Type)
                    {
                        case JTokenType.Integer:
                            break;
                    }
                    PropertyInfo pi = protoConfigType.GetProperty(p.Name);

                    bool hasSpecial = false;
                    for (int j = 0; j < configParam.Count; j++)
                    {
                        if (configParam[j].paramName == p.Name  )
                        {
                            if (configParam[j].paramType == ParamType.ParamType_MultipleObjects)
                            {
                                IList list = (IList) pi.GetValue(protoObj);
                                string str = (string) p.Value;
                                if (str != "NULL" && str.Length != 0)
                                {
                                    string[] strs = str.Split(';');
                                    for (int i = 0; i < strs.Length; i++)
                                    {
                                        list.Add(strs[i]);
                                    }
                                }

                                hasSpecial = true;
                            }

                            if (configParam[j].paramType == ParamType.ParamType_IntentionCondition)
                            {
                                IList list = (IList) pi.GetValue(protoObj);
                                string str = (string) p.Value;
                                if (str != "NULL" && str.Length != 0)
                                {
                                    string[] tmpConditionStr = str.Split('|');
                                    for (int m = 0; m < tmpConditionStr.Length; m++)
                                    {
                                        var mathes = Regex.Matches(tmpConditionStr[m].Trim(), pattern);
                                        if (mathes.Count >= 3)
                                        {
                                            Type intentionConditionType = assembly.GetType(protoPackageName + ".IntentionCondition");
                                            Object tmpIC = Activator.CreateInstance(intentionConditionType);
                                            PropertyInfo piTmpIC = intentionConditionType.GetProperty("conditionParams" );
                                            IList listTmp = (IList) piTmpIC.GetValue(tmpIC);
                                            for ( int i = 0; i < 2; i++ )
                                            {
                                                listTmp.Add(mathes[i].ToString());
                                            }

                                            string[] paramsMatches =  mathes[2].ToString().Split(';'); 
                                            for ( int i = 0; i < paramsMatches.Length; i++ )
                                            {
                                                listTmp.Add(paramsMatches[i]);
                                            }

                                            list.Add(tmpIC);
                                        }
                                    }
                                }
                                hasSpecial = true;
                            }
                        }
                    }

                    if (!hasSpecial)
                    {
                        pi.SetValue(protoObj, p.Value.ToObject(pi.PropertyType), null);    
                    }
                }
            }
            if (protoObj != null)
            {
                result.Add(protoObj);
            }
        }

        private static string GetProroTypeString(ParamType type)
        {
            string tmpStr = "required ";
            switch (type)
            {
                case ParamType.ParamType_Float:
                    tmpStr += "float";
                    break;
                case ParamType.ParamType_Int:
                    tmpStr += "int32";
                    break;
                case ParamType.ParamType_long:
                    tmpStr += "int64";
                    break;
                case ParamType.ParamType_String:
                    tmpStr += "string";
                    break;
                case ParamType.ParamType_UInt:
                    tmpStr += "uint32";
                break;
                case ParamType.ParamType_MultipleObjects:
                    return "repeated string";
                case ParamType.ParamType_IntentionCondition:
                    return "repeated IntentionCondition";
            }
            return tmpStr;
        }

    }
}
