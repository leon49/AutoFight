using System.Collections.Generic;
using CSVToJsonAndCS;

namespace BatchOutputConfigure
{
    public class TmpClassForThread
    {
        public string fileName = "";
        public string jsonFilePath = "";
        public List<ParamData> listParamData = new List<ParamData>();
        public string configureResult = "";
        public string logStr = "";
    }
}
