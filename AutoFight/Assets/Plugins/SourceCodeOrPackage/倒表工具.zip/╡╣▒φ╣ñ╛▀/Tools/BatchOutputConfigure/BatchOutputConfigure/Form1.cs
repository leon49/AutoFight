﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using System.Xml;
using System.IO;
using CSVToJsonAndCS;
using System.Threading;
using Newtonsoft.Json;
//using SharpSvn;
using System.Diagnostics;
using System.Text.RegularExpressions;

public enum TabelType
{
    NORMAL = 0, //数据配置表
    lAN, //多语言表
    DEFAULT, //默认配置表
}

namespace BatchOutputConfigure
{
    public enum SystemLanguage
    {
        Afrikaans = 0,
        Arabic = 1,
        Basque = 2,
        Belarusian = 3,
        Bulgarian = 4,
        Catalan = 5,
        Chinese = 6,
        Czech = 7,
        Danish = 8,
        Dutch = 9,
        English = 10,
        Estonian = 11,
        Faroese = 12,
        Finnish = 13,
        French = 14,
        German = 15,
        Greek = 16,
        Hebrew = 17,
        Hungarian = 18,
        Hugarian = 18,
        Icelandic = 19,
        Indonesian = 20,
        Italian = 21,
        Japanese = 22,
        Korean = 23,
        Latvian = 24,
        Lithuanian = 25,
        Norwegian = 26,
        Polish = 27,
        Portuguese = 28,
        Romanian = 29,
        Russian = 30,
        SerboCroatian = 31,
        Slovak = 32,
        Slovenian = 33,
        Spanish = 34,
        Swedish = 35,
        Thai = 36,
        Turkish = 37,
        Ukrainian = 38,
        Vietnamese = 39,
        Cantonese = 40,
        TaiWan = 41,
        Unknown = 42,
        ChineseICP = 43,
        All = 44
    }

    public delegate void set_Text(string s, bool end, string result); //定义委托

    public partial class Form1 : Form
    {
        static string batchExcelPathKey = "Batch_Excel_Path";
        static string dirPathKey = "Project_Dir_Path";
        static string unityDirPathKey = "Unity_Project_Dir_Path";

        public class TableInfo
        {
            public string path;

            //类型（0:配置表，1:多语言表， 2：默认值配置表）
            public TabelType type; //类型（0:配置表，1:多语言表，2:背景音乐配置表，3:音效配置表， 4：默认值配置表，5：文明配置表）
            public bool isOutput; //true: 输出，false: 不输出
            public bool isLocal;
        }

        private class PathInfo
        {
            public string csPath;
            public string jsonPath;
            public string lanPath;
            public string versionPath;
        }

        private class SelectOutputInfo
        {
            public TableInfo info;
            public bool isSelect;
        }

        public enum OutputState
        {
            start = 0,
            stop,
            end
        }

        private string _dirPath;
        private string _unityDirPath;
        private string _csPath;
        private string _jsonPath;
        private string _serverJsonPath;
        private string _lanPath;
        private string _serverLanPath = "server\\server2\\language";
        private string _configVersionPath = "client\\EvonyMobile\\ConfigureVersion";
        private List<TableInfo> tabelList;
        private List<SelectOutputInfo> listSelectOutput = new List<SelectOutputInfo>();
        private PathInfo _pathInfo = new PathInfo();

        private string lanErrorContent = "";
        private Thread thread;


        set_Text Set_Text; //定义委托

        private Microsoft.Office.Interop.Excel.Application _excel = null;
        private string currentSVNVersion;
        private bool _isSelectAll = true;
        private bool _isSetCheck = false;
        private int _selectLan;

        public int selectLan
        {
            get { return _selectLan; }
            set
            {
                _selectLan = value;
                if (_selectLan > 1)
                {
                    _selectLan = 0;
                }
            }
        }

        private OutputState _state = OutputState.end;
        private System.Object lockObject = new System.Object();
        private bool _lanTypeError = false;

        Dictionary<string, string> _dicKeyValue = new Dictionary<string, string>();

        Dictionary<string, Dictionary<string, string>> _dicCnKeyToFormatString =
            new Dictionary<string, Dictionary<string, string>>();

        Dictionary<string, string> _dicCnKeyToValue = new Dictionary<string, string>();
        Dictionary<string, string> _dicEnKeytoValue = new Dictionary<string, string>();
        Dictionary<string, string> _dicTextColorStrings = new Dictionary<string, string>();
        Dictionary<string, string> _dicLanKeyToType = new Dictionary<string, string>();

        private Dictionary<string, SystemLanguage> LanDic = new Dictionary<string, SystemLanguage>()
        {
            {"en-US", SystemLanguage.English},
            {"fr-FR", SystemLanguage.French},
            {"it-IT", SystemLanguage.Italian},
            {"de-DE", SystemLanguage.German},
            {"es-ES", SystemLanguage.Spanish},
            {"ru-RU", SystemLanguage.Russian},
            {"ko-KR", SystemLanguage.Korean},
            {"ja-JP", SystemLanguage.Japanese},
            {"pt-BR", SystemLanguage.Portuguese},
            {"ar-AE", SystemLanguage.Arabic},
            {"ms-MY", SystemLanguage.Basque},
            {"nb-NO", SystemLanguage.Norwegian},
            {"nl-NL", SystemLanguage.Dutch},
            {"th-TH", SystemLanguage.Thai},
            {"tr-TR", SystemLanguage.Turkish},
            {"vi-VN", SystemLanguage.Vietnamese},
            {"id-ID", SystemLanguage.Indonesian},
            {"zh-CN", SystemLanguage.Chinese},
            {"sv-SE", SystemLanguage.Swedish},
            {"he-IL", SystemLanguage.Hebrew},
            {"da-DK", SystemLanguage.Danish},
            {"ro-MO", SystemLanguage.Romanian},
            {"fp-PH", SystemLanguage.Faroese},
            {"zh-TW", SystemLanguage.Cantonese},
            {"zh-ICP", SystemLanguage.ChineseICP},
        };

        private class ClassInfo
        {
            public string note;
            public string keyName;
        }

        public Form1()
        {
            _excel = new Microsoft.Office.Interop.Excel.Application();
            _excel.Visible = false;
            _excel.UserControl = true;

            InitializeComponent();
            string configPath = ConfigurePath();
            if (File.Exists(configPath) == true)
            {
                string[] lines = File.ReadAllLines(configPath);
                for (int i = 0; i < lines.Length; ++i)
                {
                    string line = lines[i];
                    string[] arrString = line.Split('=');
                    if (arrString.Length >= 2)
                    {
                        if (arrString[0].Equals(batchExcelPathKey))
                        {
                            textBoxExcel.Text = arrString[1].Trim();
                        }
                        else if (arrString[0].Equals(dirPathKey))
                        {
                            textBoxDir.Text = arrString[1].Trim();
                        }
                        else if (arrString[0].Equals(unityDirPathKey))
                        {
                            textBox1.Text = arrString[1].Trim();
                            ConfigPath.ProjectName = getFolderName(textBox1.Text);
                            JsonToProtoBuf.UnityProjPath = textBox1.Text;
                        }

                        _dicKeyValue[arrString[0]] = arrString[1];
                    }
                }
            }

            Set_Text = new set_Text(set_resultText); //实例化
            LogTime.TextBox = richTextBox1;
            LogTime.SetText = Set_Text;
            checkedListBox1.ItemCheck += ItemCheckEventHandler;
            checkedListBox1.Items.Clear();
            ReadBatchOutputContent(false, true);
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _excel.Quit();
            _excel = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        //读取批量处理文件
        private bool ReadBatchOutputContent(bool showError, bool refreUI)
        {
            string excelFilePath = textBoxExcel.Text;
            if (excelFilePath.Length <= 0 || !File.Exists(excelFilePath))
            {
                MessageBox.Show("选择的Excel文件不存在");
                return false;
            }

            tabelList = null;
            bool res = GetTableInfo(excelFilePath, out tabelList, _pathInfo);
            if (res == false)
            {
                MessageBox.Show("批量输出Excel格式不正确");
                return false;
            }

            listSelectOutput.Clear();
            for (int i = 0; i < tabelList.Count; ++i)
            {
                TableInfo info = tabelList[i];
                if (info.isOutput == true)
                {
                    SelectOutputInfo selectInfo = new SelectOutputInfo();
                    selectInfo.info = info;
                    selectInfo.isSelect = true;
                    listSelectOutput.Add(selectInfo);
                }
            }

            if (refreUI)
                RefreshCheckListBox();
            return true;
        }

        private void ExcelButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDlg = new OpenFileDialog();

            //设置文件类型  
            openFileDlg.Filter = " excel files(*.xlsx)|*.xlsx| excel files(*.xls)|*.xls";

            //设置默认文件类型显示顺序  
            openFileDlg.FilterIndex = 1;

            //保存对话框是否记忆上次打开的目录  
            openFileDlg.RestoreDirectory = true;

            //点了保存按钮进入  
            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDlg.FileName;
                if (fileName != "")
                {
                    textBoxExcel.Text = fileName;
                    SetValue(batchExcelPathKey, fileName);
                    ReadBatchOutputContent(true, true);
                }
            }
        }

        private void DirButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();
            folderBrowserDialog1.Description = "请选择Docs配置表路径";
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string folderName = folderBrowserDialog1.SelectedPath;
                if (folderName != "")
                {
                    textBoxDir.Text = folderName;
                    SetValue(dirPathKey, folderName);
                }
            }
        }

        private void UnityDirButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();
            folderBrowserDialog1.Description = "请选择Unity项目空间路径";
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string folderName = folderBrowserDialog1.SelectedPath;
                if (folderName != "")
                {
                    textBox1.Text = folderName;
                    ConfigPath.ProjectName = getFolderName(folderName);
                    JsonToProtoBuf.UnityProjPath = folderName;
                    SetValue(unityDirPathKey, folderName);
                }
            }
        }

        public string getFolderName(string aPath)
        {
            string[] tStrAry = aPath.Split('\\');
            return tStrAry[tStrAry.Length - 1];
        }

        private void OutputButton_Click(object sender, EventArgs e)
        {
            string excelFilePath = textBoxExcel.Text;
            _dirPath = textBoxDir.Text;
            _unityDirPath = textBox1.Text;

            if (excelFilePath.Length == 0)
            {
                MessageBox.Show("请选择Excel文件");
                return;
            }

            bool res = File.Exists(excelFilePath);
            if (res == false)
            {
                MessageBox.Show("选择的Excel文件不存在");
                return;
            }

            if (_dirPath.Length == 0)
            {
                MessageBox.Show("请选择工程根目录");
                return;
            }

            res = Directory.Exists(_dirPath);
            if (res == false)
            {
                MessageBox.Show("工程根目录不存在");
                return;
            }

            if (_unityDirPath.Length == 0)
            {
                MessageBox.Show("请选择Unity项目空间路径");
                return;
            }

            if (listSelectOutput.Count == 0)
            {
                MessageBox.Show("批量输出文件个数为0");
                return;
            }

            if (_pathInfo.csPath.Length == 0)
            {
                MessageBox.Show("C#输出路径不存在");
                return;
            }

            _csPath = Path.Combine(_unityDirPath, _pathInfo.csPath);
            res = Directory.Exists(_csPath);
            if (res == false)
            {
                Directory.CreateDirectory(_csPath);
            }

            if (_pathInfo.jsonPath.Length == 0)
            {
                MessageBox.Show("json输出路径不存在");
                return;
            }

            _jsonPath = Path.Combine(_unityDirPath, _pathInfo.jsonPath);
            res = Directory.Exists(_jsonPath);
            if (res == false)
            {
                Directory.CreateDirectory(_jsonPath);
            }

            if (_pathInfo.lanPath.Length == 0)
            {
                MessageBox.Show("多语言输出路径不存在");
                return;
            }

            _lanPath = Path.Combine(_unityDirPath, _pathInfo.lanPath);
            res = Directory.Exists(_lanPath);
            if (res == false)
            {
                Directory.CreateDirectory(_lanPath);
            }

            _configVersionPath = Path.Combine(_unityDirPath, _pathInfo.versionPath);
            res = Directory.Exists(_configVersionPath);
            if (res == false)
            {
                Directory.CreateDirectory(_configVersionPath);
            }

            lock (lockObject)
            {
                if (_state == OutputState.start)
                {
                    _state = OutputState.stop;
                    OutputButton.Enabled = false;
                    return;
                }
                else if (_state == OutputState.end)
                {
                    _state = OutputState.start;
                    OutputButton.Text = "停止";
                }
                else
                {
                    return;
                }
            }

            richTextBox1.Text = "";

            checkedListBox1.Enabled = false;
            LoadBatchButton.Enabled = false;
            SelectAllButton.Enabled = false;
            ExcelButton.Enabled = false;
            DirButton.Enabled = false;
            currentSVNVersion = "";

            thread = new Thread(new ThreadStart(run));
            thread.Start();
        }

        protected bool isNumberic(string message, out int result)
        {
            //判断是否为整数字符串
            //是的话则将其转换为数字并将其设为out类型的输出值、返回true, 否则为false
            result = -1; //result 定义为out 用来输出值
            try
            {
                //当数字字符串的为是少于4时，以下三种都可以转换，任选一种
                result = Convert.ToInt32(message);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void DeleteDirFiles(string dir)
        {
            DirectoryInfo theFolder = new DirectoryInfo(dir);
            FileInfo[] fileInfo = theFolder.GetFiles();
            foreach (FileInfo NextFile in fileInfo)
            {
                File.Delete(NextFile.FullName);
            }
        }

        public delegate void ParameterizedThreadStart(Object obj);

        public static string allResult = "";
        private Dictionary<string, string> dicConfigureFileInfo;
        private Dictionary<string, string> dicSaveConfigureFileInfo;
        string configureResult = "";
        private List<string> configJsonFileList;
        private List<List<ParamData>> configParamList;

        private int maxThread = 0;
        private int threadCompleteCount = 0;

        private void run()
        {
            LogTime.init();
            _lanTypeError = false;
            _dicCnKeyToFormatString.Clear();
            _dicCnKeyToValue.Clear();
            _dicEnKeytoValue.Clear();
            _dicLanKeyToType.Clear();

            string configureFileInfoPath = _configVersionPath + "\\ConfigureFileInfo.txt";
            dicConfigureFileInfo = new Dictionary<string, string>();
            if (File.Exists(configureFileInfoPath))
                dicConfigureFileInfo =
                    JsonConvert.DeserializeObject<Dictionary<string, string>>(File.ReadAllText(configureFileInfoPath));

            AdjustSelctOutput();
            bool checkFile = true;

            configJsonFileList = new List<string>();
            configParamList = new List<List<ParamData>>();
            dicSaveConfigureFileInfo = new Dictionary<string, string>();
            lanErrorContent = "";

            maxThread = listSelectOutput.Count;
            threadCompleteCount = 0;
            foreach (SelectOutputInfo selectInfo in listSelectOutput)
            {
                lock (lockObject)
                {
                    if (_state == OutputState.stop)
                    {
                        checkFile = false;
                        break;
                    }
                }

                if (selectInfo.isSelect == false)
                {
                    checkFile = false;
                    continue;
                }


                TableInfo info = selectInfo.info;
                if (info.isOutput == true)
                {
                    string path = _dirPath + "\\" + info.path;
                    #region 配置表 默认配置表
                    if (info.type == TabelType.NORMAL || info.type == TabelType.DEFAULT)
                    {
                        bool isNewVersion = false;
                        string fileName = "";
                        List<ParamData> listParamData;
                        string result = ExcelToCSAndJson(path, _csPath, _jsonPath, _serverJsonPath, _dirPath, info.isLocal, out isNewVersion, out fileName,out listParamData,info.type);
                        if (info.isLocal == false)
                        {
                            if (fileName.Length > 0)
                                dicSaveConfigureFileInfo[fileName] = "1";
                        }
  
                        allResult += result + "\r\n";
                        configJsonFileList.Add(_jsonPath + "\\" + fileName + ".txt");
                        configParamList.Add(listParamData);

                    }
                    #endregion
                    #region 多语言表
                    else if (info.type == TabelType.lAN)
                    {
                        string repeatKey = "";
                        string result = ExcelToLanTxt(path, _lanPath, out repeatKey);
                        allResult += result + "\r\n";

                        if (repeatKey.Length > 0)
                            configureResult += "[" + _lanPath + "] => " + repeatKey + "\r\n";
                    }
                    #endregion
                }
                else
                {
                    allResult += "[" + info.path + "] 不输出\r\n";
                }

                richTextBox1.Invoke(Set_Text, new object[]{allResult, false, ""});
                Thread.Sleep(50);
            }
            
            Json2CSProto(checkFile);
        }

        public void Json2CSProto(bool checkFile)
        {
            LogTime.LogStepTime("\r\nDebug: Excel转Json over");
            bool isConfigureChanged = false;
            if (isConfigureChanged == false && checkFile == true)
            {
                foreach (string tempString in dicConfigureFileInfo.Keys)
                {
                    if (dicSaveConfigureFileInfo.ContainsKey(tempString) == false)
                    {
                        isConfigureChanged = true;
                        configureResult += tempString + "配置文件被删除！\n";
                    }
                }
            }

            if (isConfigureChanged)
            {
                configureResult += "\n\n配置表结构有变化，请确认不要上传变化的配置表。\n SVN 版本号： " + currentSVNVersion + "\n";
            }

            JsonToProtoBuf.dirPath = _dirPath;
            allResult = JsonToProtoBuf.ConvertJsonToProtoBuf(_serverJsonPath, configJsonFileList, configParamList,
                richTextBox1, Set_Text, allResult);

            LogTime.LogStepTime("\r\nDebug: Json转ProtoBuf over");

            string lanErrorPath = _dirPath + "\\多语言问题表.txt";
            if (lanErrorContent.Length == 0)
            {
                if (File.Exists(lanErrorPath))
                {
                    File.Delete(lanErrorPath);
                }
            }
            else
            {
                File.WriteAllText(lanErrorPath, lanErrorContent);
                allResult += "\r\n多语言有问题请检查'多语言问题表'！";
            }

            allResult += "\r\n" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.TimeOfDay + "\r\n\r\n\r\n\r\n";
            richTextBox1.Invoke(Set_Text, new object[] {allResult, true, configureResult});
            LogTime.LogStepTime();
        }


        private bool IsOutputLan()
        {
            foreach (SelectOutputInfo selectInfo in listSelectOutput)
            {
                if (selectInfo.info.type == TabelType.lAN && selectInfo.isSelect == true)
                {
                    return true;
                }
            }

            return false;
        }

        private void AdjustSelctOutput()
        {
            if (IsOutputLan() == false)
            {
                return;
            }

            SelectOutputInfo selectCnInfo = null;

            SelectOutputInfo selectEnInfo = null;
            SelectOutputInfo selectTextColorInfo = null;
            foreach (SelectOutputInfo selectInfo in listSelectOutput)
            {
                if (selectInfo.info.type == TabelType.lAN && selectInfo.info.path.Contains("en-US"))
                {
                    selectInfo.isSelect = true;
                    selectEnInfo = selectInfo;
                }
                else if (selectInfo.info.type == TabelType.lAN && selectInfo.info.path.Contains("zh-CN"))
                {
                    selectInfo.isSelect = true;
                    selectCnInfo = selectInfo;
                }

                if (selectInfo.info.path.Contains("文本颜色配置表"))
                {
                    selectInfo.isSelect = true;
                    selectTextColorInfo = selectInfo;
                }
            }

            listSelectOutput.Remove(selectEnInfo);
            listSelectOutput.Insert(0, selectEnInfo);
        }

        private void SetValue(String AppKey, String AppValue)
        {
            _dicKeyValue[AppKey] = AppValue;
            string saveContent = "";
            foreach (string key in _dicKeyValue.Keys)
            {
                saveContent += key + "=" + _dicKeyValue[key] + "\r\n";
            }

            string configPath = ConfigurePath();
            File.WriteAllText(configPath, saveContent);
        }

        private string ConfigurePath()
        {
            return System.Windows.Forms.Application.LocalUserAppDataPath + "\\Configure.txt";
        }

        //读取TabelInfo
        private bool GetTableInfo(string excelFilePath, out List<TableInfo> listOutputInfo, PathInfo pathInfo)
        {
            listOutputInfo = new List<TableInfo>();

            object missing = System.Reflection.Missing.Value;
            if (!excelFilePath.EndsWith(".xlsx") && !excelFilePath.EndsWith(".xls"))
                return false;

            Workbook wb = _excel.Application.Workbooks.Open(excelFilePath, missing, true, missing, missing, missing);
            Worksheet ws = (Worksheet) wb.Worksheets.get_Item(1);
            if (ws == null || ws.UsedRange.Cells.Rows.Count < 5 || ws.UsedRange.Cells.Columns.Count < 5)
            {
                wb.Close(false);
                return false;
            }

            var Rng = ws.UsedRange.Cells;
            object[,] arr = (object[,]) ws.Cells.get_Range("A1", ToExcelTag(Rng.Columns.Count) + Rng.Rows.Count).Value2;

            /*************路径信息*********************/
            //CSPath
            pathInfo.csPath = arr[1, 2].ToString();
            //JsonPath
            pathInfo.jsonPath = arr[2, 2].ToString();
            //MultiLanPath
            pathInfo.lanPath = arr[3, 2].ToString();
            //VersionPath
            pathInfo.versionPath = arr[4, 2].ToString();

            pathInfo.versionPath = arr[4, 2].ToString();
            /****************************************/

            /*************表信息********************/
            int row_no = 6;
            while (row_no <= Rng.Rows.Count)
            {
                System.Func<object, object, object, TableInfo> readTabel = (oPath, oType, oOutPut) =>
                {
                    if (oPath == null || oType == null)
                        return null;

                    var info = new TableInfo();
                    info.path = oPath.ToString();
                    info.type = (TabelType) int.Parse(oType.ToString());
                    info.isOutput = true;
                    if (oOutPut != null)
                        info.isOutput = oOutPut.ToString().Equals("0") ? false : true;
                    return info;
                };

                var item = readTabel(arr[row_no, 2], arr[row_no, 3], arr[row_no, 4]);
                if (item != null)
                    listOutputInfo.Add(item);

                row_no++;
            }
            /************************************/

            wb.Close(false);
            return true;
        }

        //将数字转化为Excel的A~Z标识
        private string ToExcelTag(int columns)
        {
            int a = columns / 26;
            int b = columns % 26;

            string str = "";
            string str2 = "";
            if (a > 0)
            {
                Char ch = 'A';
                ch += (Char) (a - 1);
                str = ch.ToString();
            }

            if (b == 0)
            {
                str2 = "Z";
            }
            else
            {
                Char ch = 'A';
                ch += (Char) (b - 1);
                str2 = ch.ToString();
            }

            return str + str2;
        }

        /// <summary>
        /// eccel表转化为json表
        /// </summary>
        private string ExcelToCSAndJson(string excelPath, string csPath, string jsonPath, string serverJsonPath,
            string baseDirPath, bool isLocal, out bool isNewVersion, out string fileName,
            out List<ParamData> listParamData, TabelType fileType = 0)
        {
            listParamData = new List<ParamData>();
            isNewVersion = false;
            fileName = "";
            if (File.Exists(excelPath) == false)
                return "Error: [" + excelPath + "] 文件不存在！";

            object missing = System.Reflection.Missing.Value;
            if (!excelPath.EndsWith(".xlsx") && !excelPath.EndsWith(".xls"))
                return "";

            Workbook wb = null;
            Worksheet ws = null;
            try
            {
                wb = _excel.Application.Workbooks.Open(excelPath, missing, true, missing, missing, missing);
            }
            catch (Exception e)
            {
                return e.ToString();
//                return "Error: [" + excelPath + "] 无法打开,请不要使用非微软的excel编辑！";
            }

            ws = (Worksheet) wb.Worksheets.get_Item(1);
            if (ws == null)
                return "";

            #region 类名

            System.Func<string> getClassName = () =>
            {
                int rows = ws.UsedRange.Cells.Rows.Count;
                int cols = ws.UsedRange.Cells.Columns.Count;
                if (rows <= 0 || cols < 2)
                    return "";

                string column = ToExcelTag(cols);
                var rng = ws.Cells.get_Range("A1", column + rows);

                object[,] arr = (object[,]) rng.Value2;
                for (int i = 1; i <= cols; ++i)
                {
                    if (arr[1, i] != null && arr[1, i].ToString().Equals("class"))
                        return arr[1, i + 1].ToString();
                }

                return "";
            };

            fileName = getClassName();
            if (fileName.Length == 0)
            {
                if (wb != null)
                    wb.Close(false);

                return "Error: [" + excelPath + "] 没有指定class名字！";
            }

            #endregion

            int index = excelPath.LastIndexOf("\\");
            string csvPath = excelPath.Substring(0, index) + "\\" + fileName + ".txt";

            bool res = excelToCSV(excelPath, csvPath, wb);
            if (wb != null)
                wb.Close(false);

            if (!res)
                return "Error: [" + excelPath + "] Excel转CSV失败！";


            string excelName = excelPath.Substring(index + 1, excelPath.Length - index - 1);

            string result = CSVToJson.commonCSVToJson(csvPath, csPath, jsonPath, fileName, baseDirPath,
                _configVersionPath, out isNewVersion, out listParamData, excelName, fileType);


            if (excelPath.Contains("文本颜色配置表"))
            {
                _dicTextColorStrings.Clear();
                string jsonFilePath = jsonPath + "\\" + fileName + ".txt";
                string text = File.ReadAllText(jsonFilePath);
                _dicTextColorStrings = JsonConvert.DeserializeObject<Dictionary<string, string>>(text);
            }

            /*
            string fromPath = jsonPath + "\\" + fileName + ".txt";
            string toPath = serverJsonPath + "\\" + fileName + ".txt";
            if (File.Exists(fromPath))
            {
                File.Copy(fromPath, toPath, true);
            }
             * */


            File.Delete(csvPath);

            if (isNewVersion)
            {
                listParamData.Clear();
                return "Error:［" + excelPath + "]\r\n" + result;
            }

            return "Success:［" + excelPath + "]";
        }

        private void AdjustParamData(List<ParamData> list)
        {
            List<ParamData> newList = new List<ParamData>();
            foreach (ParamData data in list)
            {
                newList.Add(data);
                if (data.type == ParamDataType.ParamDataType_ResAndParam)
                {
                    ParamData newData = new ParamData();
                    newData.type = ParamDataType.ParamDataType_OnlyParam;
                    newData.paramType = ParamType.ParamType_String;
                    newData.paramName = data.paramName + "_res";
                    newList.Add(newData);
                }
            }

            list.Clear();
            list.AddRange(newList);
        }

        private bool excelToCSV(string excelFilePath, string csvFilePath, Workbook wb)
        {
            object missing = System.Reflection.Missing.Value;
            Worksheet ws = null;
            ws = (Worksheet) wb.Worksheets.get_Item(1);
            if (ws == null)
                return false;

            string a = "";
            int row_no = 1;

            int rows = ws.UsedRange.Cells.Rows.Count;
            int cols = ws.UsedRange.Cells.Columns.Count;

            string column = ToExcelTag(cols);
            Microsoft.Office.Interop.Excel.Range rng1 = ws.Cells.get_Range("A1", column + rows);

            object[,] arry1 = (object[,]) rng1.Value2;

            while (row_no <= rows)
            {
                bool addReturn = true;
                for (int i = 1; i <= cols; i++)
                {
                    if (row_no == 1)
                    {
                        if (arry1[row_no, i] == null)
                        {
                            continue;
                        }

                        string temp = arry1[row_no, i].ToString();
                        if (temp.Equals("class"))
                        {
                            addReturn = false;
                            break;
                        }
                    }

                    if (arry1[row_no, i] == null)
                    {
                        a += "" + ",";
                    }
                    else
                    {
                        a += arry1[row_no, i].ToString() + ",";
                    }
                }

                row_no++;
                if (addReturn)
                    a += "\n";
            }

            StreamWriter csv = new StreamWriter(@csvFilePath, false, Encoding.UTF8);
            csv.Write(a);
            csv.Close();
            return true;
        }

        //多语言处理
        private string ExcelToLanTxt(string excelFilePath, string resFolder, out string repeatKey)
        {
            repeatKey = "";
            object missing = System.Reflection.Missing.Value;
            if (!excelFilePath.EndsWith(".xlsx") && !excelFilePath.EndsWith(".xls"))
                return "Error: 多语言 [" + excelFilePath + "] 文件读取失败！";

            Workbook wb = _excel.Application.Workbooks.Open(excelFilePath, missing, false, missing, missing, missing);

            Worksheet ws = (Worksheet) wb.Worksheets.get_Item(1);

            if (ws == null)
            {
                wb.Close(false);
                return "Error: 多语言 [" + excelFilePath + "] 文件读取失败！";
            }


            Dictionary<string, string> dicBackupKeyToType = new Dictionary<string, string>();
            string verPath = _configVersionPath + "\\" + "zh-CN.txt";

            SystemLanguage lanType = 0;
            if (excelFilePath.Contains("zh-CN"))
            {
                lanType = SystemLanguage.Chinese;
                //读取key的备份
                if (File.Exists(verPath))
                    dicBackupKeyToType =
                        JsonConvert.DeserializeObject<Dictionary<string, string>>(File.ReadAllText(verPath));
            }
            else if (excelFilePath.Contains("zh-ICP"))
            {
                lanType = SystemLanguage.ChineseICP;
            }
            else if (excelFilePath.Contains("en-US"))
            {
                lanType = SystemLanguage.English;
            }


            string output = "";
            string tableName = Path.GetFileNameWithoutExtension(excelFilePath).Trim();
            int rows = ws.UsedRange.Cells.Rows.Count;
            int cols = ws.UsedRange.Cells.Columns.Count;
            var arr = (object[,]) ws.Cells.get_Range("A1", ToExcelTag(cols) + rows).Value2;


            bool change = false;

            string tempContent = "";

            string content = "";
            int addCount = 0;
            repeatKey = "";
            Dictionary<string, string> dicText = new Dictionary<string, string>();
            Dictionary<string, string> dicLanKeyToValue = new Dictionary<string, string>();
            string errorContent = "";
            for (int row = 2; row <= rows; ++row)
            {
                if (arr[row, 2] == null || arr[row, 3] == null)
                    continue;

                string key = arr[row, 2].ToString();
                string value = arr[row, 3].ToString();

                if (key == null || value == null)
                {
                    wb.Close(false);
                    return "Error: 多语言 [" + excelFilePath + "] 文件格式不正确！";
                }

                key = key.Trim();
                value = value.Trim();
                if (key.Length == 0 || value.Length == 0)
                    continue;

                string tempValue = value;
                if (_dicLanKeyToType.ContainsKey(key) && _dicLanKeyToType[key].Equals("4"))
                    value = FormatStringForTextColor(value);


                if (lanType == SystemLanguage.Chinese)
                    _dicCnKeyToValue[key] = value;
                else
                {
                    if (lanType == SystemLanguage.English)
                        _dicEnKeytoValue[key] = value;

                    dicLanKeyToValue[key] = value;
                }

                #region 占位符是否统一

                bool error = false;
                Dictionary<string, string> dicFormatString = CheckFormatString(value, out error);
                if (error == true)
                    errorContent += "Key[" + key + "] 对应的value有错误！\r\n";
                else
                {
                    if (lanType == SystemLanguage.Chinese)
                        _dicCnKeyToFormatString[key] = dicFormatString;

                    else
                    {
                        if (_dicCnKeyToFormatString.ContainsKey(key))
                        {
                            Dictionary<string, string> dicCnFormatString = _dicCnKeyToFormatString[key];
                            if (dicCnFormatString.Count != dicFormatString.Count)
                            {
                                errorContent += "Key[" + key + "] 对应的占位符个数和[zh-CN]不一样！\r\n";
                            }
                            else
                            {
                                if (dicCnFormatString.Count > 0)
                                {
                                    foreach (string formatKey in dicCnFormatString.Keys)
                                    {
                                        if (dicFormatString.ContainsKey(formatKey) == false)
                                        {
                                            errorContent += "Key[" + key + "] 对应的字符串格式化内容和[zh-CN]不一样！\r\n";
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                #endregion

                #region  统计重复的key

                if (dicText.ContainsKey(key))
                {
                    if (repeatKey.Length == 0)
                        repeatKey = "Error: 重复key[" + key;
                    else
                        repeatKey += "," + key;
                }

                #endregion


                dicText[key] = tempValue;
                addCount++;
                content += string.Format("\"{0}\"=\"{1}\";\r\n", key, value);
            }

            //检查各语言之间的差异
            if (lanType != SystemLanguage.Chinese)
            {
                //中文多出的key
                string strCnAddKey = "";
                foreach (string key in _dicCnKeyToValue.Keys)
                    if (dicLanKeyToValue.ContainsKey(key) == false)
                        strCnAddKey += key + "\r\n";

                if (strCnAddKey.Length > 0 && dicLanKeyToValue.Count > 0 &&
                    (lanType == SystemLanguage.English || lanType == SystemLanguage.ChineseICP))
                    output += "中文多出的Key： \r\n" + strCnAddKey;

                //对应语言多出来的key
                string strLanAddKey = "";
                foreach (string key in dicLanKeyToValue.Keys)
                    if (_dicCnKeyToValue.ContainsKey(key) == false)
                        strLanAddKey += key + "\r\n";

                if (strLanAddKey.Length > 0)
                    output += lanType + "多出的Key： \r\n" + strLanAddKey;

                //如果其他语言没有对应的key 那么使用En来做默认补充
                foreach (string key in _dicEnKeytoValue.Keys)
                    if (dicLanKeyToValue.ContainsKey(key) == false)
                        content += string.Format("\"{0}\"=\"{1}\";\r\n", key, _dicEnKeytoValue[key]);
            }


            if (tempContent.Length > 0 && excelFilePath.Contains("he-IL") == false)
                tempContent = "\t\t" + (int) LanDic[tableName] + " => array(\r\n" + tempContent + "\t\t),\r\n";

            File.WriteAllText(resFolder + "\\" + tableName + ".txt", content); //写入resource目录
            var dicPath = Path.GetDirectoryName(excelFilePath) + "\\txt\\";
            if (!Directory.Exists(dicPath))
                Directory.CreateDirectory(dicPath);

            File.WriteAllText(dicPath + tableName + ".txt", content); //写入config目录

            output += tableName + ": " + "增加多语言" + addCount + "个" + "\r\n";

            foreach (string key in dicBackupKeyToType.Keys)
            {
                string value1 = dicBackupKeyToType[key];
                if (value1.Length == 0 || value1.Equals("0"))
                {
                    continue;
                }

                if (_dicLanKeyToType.ContainsKey(key) == false)
                {
                    _lanTypeError = true;
                    errorContent += "Key[" + key + "]对应的类型[" + value1 + "]不存在！\r\n";
                    continue;
                }


                string value2 = _dicLanKeyToType[key];
                if (value1.Equals(value2))
                {
                    continue;
                }

                if (value1.Equals("2") && value2.Equals("3"))
                {
                    continue;
                }

                _lanTypeError = true;
                errorContent += "Key[" + key + "]对应的类型[" + value1 + "]变成了[" + value2 + "]\r\n";
                continue;
            }


            if (_lanTypeError == false && _dicLanKeyToType.Count > 0)
            {
                string tempText = JsonConvert.SerializeObject(_dicLanKeyToType, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(verPath, tempText);
            }

            if (change == true)
            {
                wb.Saved = true;
                wb.SaveAs(excelFilePath,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing);
            }

            wb.Close(false);

            if (repeatKey.Length > 0)
            {
                repeatKey += "]\r\n";
                errorContent += repeatKey;
            }

            if (errorContent.Length > 0)
                lanErrorContent += "[" + tableName + "] 错误内容如下： \r\n" + errorContent + "\r\n\r\n";

            return output == null
                ? "Error: 多语言 [" + excelFilePath + "] 生成失败！"
                : "Success: 多语言 [" + excelFilePath + "] 生成成功！\r\n" + output + repeatKey;
        }

        private void set_resultText(string s, bool end, string result) //主线程调用的函数
        {
            richTextBox1.Text = s;
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
            richTextBox1.Refresh();
            if (end)
            {
                _state = OutputState.end;
                OutputButton.Text = "输出";
                OutputButton.Enabled = true;
                checkedListBox1.Enabled = true;
                LoadBatchButton.Enabled = true;
                SelectAllButton.Enabled = true;
                ExcelButton.Enabled = true;
                DirButton.Enabled = true;
                MessageBox.Show("输出完毕！\n" + result);
            }
        }

        private void LoadBatchButton_Click(object sender, EventArgs e)
        {
            ReadBatchOutputContent(true, true);
        }

        private void SelectAllButton_Click(object sender, EventArgs e)
        {
            _isSelectAll = !_isSelectAll;
            if (_isSelectAll)
            {
                selectLan = 0;
            }

            for (int i = 0; i < listSelectOutput.Count; ++i)
            {
                listSelectOutput[i].isSelect = _isSelectAll;
            }

            RefreshCheckListBox();
        }


        private void RefreshCheckListBox()
        {
            checkedListBox1.Items.Clear();

            for (int i = 0; i < listSelectOutput.Count; ++i)
            {
                SelectOutputInfo info = listSelectOutput[i];
                string content = info.info.path;
                int pos = content.LastIndexOf("\\");
                if (pos >= 0)
                {
                    content = content.Substring(pos + 1, content.Length - pos - 1);
                }

                checkedListBox1.Items.Add(content);
                _isSetCheck = true;
                checkedListBox1.SetItemChecked(i, info.isSelect);
                _isSetCheck = false;
            }

            checkedListBox1.Refresh();
        }

        public void ItemCheckEventHandler(object sender, ItemCheckEventArgs e)
        {
            if (_isSetCheck)
            {
                return;
            }

            if (e.Index >= listSelectOutput.Count)
            {
                return;
            }

            listSelectOutput[e.Index].isSelect = (e.NewValue == CheckState.Checked) ? true : false;
        }

        private Dictionary<string, string> CheckFormatString(string value, out bool error)
        {
            error = false;
            List<string> listStr = FormatString(value);
            return CheckFormatString(listStr, out error);
        }

        private List<string> FormatString(string value)
        {
            List<string> list = new List<string>();

            string formatString = value;
            string exp = @"\{\d{1,2}\w*;[^\{]+\}";
            Match match = Regex.Match(value, exp, RegexOptions.IgnoreCase);
            while (match.Success)
            {
                list.Add(match.Value);
                match = match.NextMatch();
            }

            exp = @"\{\d{1,2}\w*:[^\{]+\}";
            match = Regex.Match(value, exp, RegexOptions.IgnoreCase);
            while (match.Success)
            {
                list.Add(match.Value);
                match = match.NextMatch();
            }

            exp = @"\{\d{1,2}\}";
            match = Regex.Match(value, exp, RegexOptions.IgnoreCase);
            while (match.Success)
            {
                list.Add(match.Value);
                match = match.NextMatch();
            }

            return list;
        }

        private string FormatStringForTextColor(string replaceString)
        {
            string result = replaceString;
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string exp = @"\{#\w*\}";
            Match match = Regex.Match(replaceString, exp, RegexOptions.IgnoreCase);
            while (match.Success)
            {
                dic[match.Value] = match.Value;
                match = match.NextMatch();
            }

            foreach (string key in dic.Keys)
            {
                string value = dic[key].Substring(2, dic[key].Length - 3);
                if (_dicTextColorStrings.ContainsKey(value))
                {
                    result = result.Replace(dic[key], _dicTextColorStrings[value]);
                }
            }

            return result;
        }

        private Dictionary<string, string> CheckFormatString(List<string> listStr, out bool error)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            error = false;
            if (listStr.Count == 0)
            {
                return dic;
            }

            Dictionary<int, int> dicNumString = new Dictionary<int, int>();
            List<int> listNum = new List<int>();
            foreach (string str in listStr)
            {
                if (dic.ContainsKey(str))
                {
                    error = true;
                    break;
                }
                else
                {
                    dic[str] = str;

                    string[] res = str.Split(";".ToCharArray());
                    if (res.Length != 2)
                    {
                        res = str.Split(":".ToCharArray());
                    }

                    if (res.Length == 2)
                    {
                        string left = res[0].Trim('{');
                        int num = int.Parse(left);
                        if (dicNumString.ContainsKey(num))
                        {
                            error = true;
                            break;
                        }
                        else
                        {
                            dicNumString[num] = num;
                            listNum.Add(num);
                        }
                    }
                }
            }

            if (listNum.Count > 0)
            {
                listNum.Sort();
                for (int i = 0; i < listNum.Count; ++i)
                {
                    if (i != listNum[i])
                    {
                        error = true;
                        break;
                    }
                }
            }

            return dic;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (selectLan == 0)
            {
                for (int i = 0; i < listSelectOutput.Count; ++i)
                {
                    SelectOutputInfo selectInfo = listSelectOutput[i];
                    selectInfo.isSelect = false;
                    if (selectInfo.info.type == TabelType.lAN)
                    {
                        selectInfo.isSelect = true;
                    }
                }
            }
            else
            {
                for (int i = 0; i < listSelectOutput.Count; ++i)
                {
                    SelectOutputInfo selectInfo = listSelectOutput[i];
                    selectInfo.isSelect = false;
                    if (selectInfo.info.type != TabelType.lAN)
                    {
                        selectInfo.isSelect = true;
                    }
                }
            }

            selectLan++;
            RefreshCheckListBox();
        }

        private void textBoxDir_TextChanged(object sender, EventArgs e)
        {
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}