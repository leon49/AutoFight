﻿using UnityEngine;

public class GesturesTemplate : ScriptableObject
{
    [SerializeField] public string xmlContent = "";
}